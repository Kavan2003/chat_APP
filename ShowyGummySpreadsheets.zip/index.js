const fs = require('fs');
const BigNumber = require('bignumber.js');

// Function to convert a number from any base to decimal
function convertToDecimal(value, base) {
    if (base <= 10) {
        return new BigNumber(value, base);
    }

    const digits = '0123456789abcdef';
    let decimal = new BigNumber(0);
    let power = new BigNumber(1);

    for (let i = value.length - 1; i >= 0; i--) {
        const digit = digits.indexOf(value[i].toLowerCase());
        decimal = decimal.plus(new BigNumber(digit).times(power));
        power = power.times(base);
    }
    return decimal;
}

// Function to print coordinates and detailed conversion steps
function printPolynomialDetails(points, constant, originalData) {
    console.log("\n=== Detailed Point Conversion ===");
    points.forEach(point => {
        const originalPoint = originalData[point.x.toString()];
        console.log(`\nPoint ${point.x}:`);
        console.log(`Original: value="${originalPoint.value}" in base ${originalPoint.base}`);
        console.log(`Converted: x=${point.x}, y=${point.y.toString()}`);
    });

    console.log("\n=== Polynomial Details ===");
    console.log(`Degree of polynomial (m): ${points.length - 1}`);
    console.log(`Constant term (c): ${constant.toString()}`);

    // Generate Lagrange basis polynomials
    console.log("\n=== Lagrange Interpolation Formula ===");
    let equation = "f(x) = ";

    points.forEach((point, i) => {
        let term = `(${point.y.toString()})`;
        points.forEach((otherPoint, j) => {
            if (i !== j) {
                term += ` * (x - ${otherPoint.x})/(${point.x} - ${otherPoint.x})`;
            }
        });
        if (i < points.length - 1) {
            term += " + ";
        }
        equation += term;
    });

    console.log(equation);
}

// Lagrange interpolation to find constant term
function findConstantTerm(points) {
    let result = new BigNumber(0);
    const x = 0; // We want to find f(0) which is our constant term

    for (let i = 0; i < points.length; i++) {
        let term = new BigNumber(points[i].y);

        for (let j = 0; j < points.length; j++) {
            if (i !== j) {
                term = term.times(
                    new BigNumber(x).minus(points[j].x)
                ).dividedBy(
                    new BigNumber(points[i].x).minus(points[j].x)
                );
            }
        }

        result = result.plus(term);
    }

    return result;
}

function processInput(inputJson) {
    try {
        // Parse input
        const data = typeof inputJson === 'string' ? JSON.parse(inputJson) : inputJson;
        const { keys: { n, k } } = data;

        console.log("\n=== Input Parameters ===");
        console.log(`Total points (n): ${n}`);
        console.log(`Required points (k): ${k}`);

        // Convert points to decimal and create array of x,y coordinates
        const points = [];
        for (let i = 1; i <= k; i++) {
            const point = data[i.toString()];
            const x = i;
            const y = convertToDecimal(point.value, parseInt(point.base));
            points.push({ x, y });
        }

        // Find the constant term (secret)
        const secret = findConstantTerm(points);

        // Print detailed information
       // printPolynomialDetails(points, secret, data);

        return secret.toString();
    } catch (error) {
        console.error('Error processing input:', error);
        throw error;
    }
}

function main() {
    try {
        // Read input from input.json file
        const rawData = fs.readFileSync('input.json');
        const jsonInput = JSON.parse(rawData);

        console.log('=== Reading Input from input.json ===');
        console.log('Input data:', JSON.stringify(jsonInput, null, 2));

        const result = processInput(jsonInput);
        console.log('\n=== Final Result ===');
        console.log('The secret (constant term) is:', result);
    } catch (error) {
        if (error.code === 'ENOENT') {
            console.error('Error: input.json file not found. Please create an input.json file with your input data.');
        } else if (error instanceof SyntaxError) {
            console.error('Error: Invalid JSON format in input.json file.');
        } else {
            console.error('Error in main:', error);
        }
        process.exit(1);
    }
}

if (require.main === module) {
    main();
}

module.exports = {
    processInput,
    convertToDecimal,
    findConstantTerm
};